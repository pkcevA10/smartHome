package com.example.why;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.NotificationCompat;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.google.android.material.navigation.NavigationView;

public class ShowActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    final String TAG = "TAG+MainActivity";
    String[] sensorData = {"0", "0", "0", "0"};

    tcpThread tcpThread;

    TextView dustText, tempText, humText;
    PendingIntent dataPendingIntent;
    NotificationManager dataNotification;

    /* Toolbar*/
    Toolbar toolbar;
    NavigationView navigationView;
    DrawerLayout drawerLayout;
    RelativeLayout contentView;

    //variable
    public static Context context;
    static final float END_SCALE = 0.7f;

    @Override
    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
    protected void onCreate(Bundle savedInstanceState) {

        Log.d(TAG, "onCreate");
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show);
        context = this;
        dustText = (TextView) findViewById(R.id.dustText);
        tempText = (TextView) findViewById(R.id.tempText);
        humText = (TextView) findViewById(R.id.humText);

        // Toolbar & navigationView, DrawerLayout
        toolbar = findViewById(R.id.toolbar);
        navigationView = findViewById(R.id.nav_view);
        drawerLayout = findViewById(R.id.drawer_layout);

        /* Toolbar */
        setSupportActionBar(toolbar);

        /* Navigation Drawer Menu */
        navigationView.bringToFront();
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawerLayout, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();

        navigationView.setNavigationItemSelectedListener(this);
        navigationView.setCheckedItem(R.id.nav_home);

        final NotificationCompat.Builder builder = new NotificationCompat.Builder(getApplicationContext(), "default");
        Intent intent = new Intent(getApplicationContext(), notificationBroadcast.class);
        dataPendingIntent = PendingIntent.getBroadcast(getApplicationContext(), 0, intent, PendingIntent.FLAG_UPDATE_CURRENT);
        builder.setSmallIcon(R.drawable.sky);
        builder.setContentTitle("실내 환경 데이터");
        builder.setContentIntent(dataPendingIntent);
        builder.setContentText("온도 = 0 습도 = 0 미세먼지 =  비 = ");
        dataNotification = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            dataNotification.createNotificationChannel(new NotificationChannel("default", "SensorData", NotificationManager.IMPORTANCE_LOW));
            //dataNotification.notify(0, builder.build());
        } else {
            //dataNotification.notify(0, builder.build());
        }
        // 센서 데이터 Notification 설정

        Handler handler = new Handler(new Handler.Callback() {
            @Override
            public boolean handleMessage(Message msg) {
                String tmp = msg.obj.toString();
                sensorData = tmp.split(",");
                tempText.setText(sensorData[0] + " ℃");
                humText.setText(sensorData[1] + " %");
                int dust = Integer.parseInt(sensorData[2]);
                if (dust >= 0 && dust <= 30) {
                    dustText.setTextColor(Color.BLUE);
                    dustText.setText("좋음 \n(" + sensorData[2] + " ㎍/㎥)");
                    builder.setContentText("온도 = " + sensorData[0] + " ℃ 습도 = " + sensorData[1] + " % 미세먼지 농도 = 좋음 (" + sensorData[2] + "㎍/㎥)");
                } else if (dust >= 31 && dust <= 80) {
                    dustText.setTextColor(Color.GREEN);
                    dustText.setText("보통 \n(" + sensorData[2] + " ㎍/㎥)");
                    builder.setContentText("온도 = " + sensorData[0] + " ℃ 습도 = " + sensorData[1] + " % 미세먼지 농도 = 보통 (" + sensorData[2] + "㎍/㎥)");
                } else if (dust >= 81 && dust <= 150) {
                    dustText.setTextColor(Color.parseColor("#FF7F00"));
                    dustText.setText("나쁨 \n(" + sensorData[2] + " ㎍/㎥)");
                    builder.setContentText("온도 = " + sensorData[0] + " ℃ 습도 = " + sensorData[1] + " % 미세먼지 농도 = 나쁨 (" + sensorData[2] + "㎍/㎥)");
                } else if (dust >= 151) {
                    dustText.setTextColor(Color.RED);
                    dustText.setText("매우나쁨 \n(" + sensorData[2] + " ㎍/㎥)");
                    builder.setContentText("온도 = " + sensorData[0] + " ℃ 습도 = " + sensorData[1] + " % 미세먼지 농도 = 매우나쁨 (" + sensorData[2] + "㎍/㎥)");
                } // 미세먼지 등급에 따라 등급과 글자색 변경
                builder.setWhen(System.currentTimeMillis()); // Notification의 시간을 실시간으로 설정
                dataNotification.notify(0, builder.build());
                return false;
            } // tcpThread 클래스로부터 넘어오는 값을 받는 Handler
        });
        tcpThread = new tcpThread(handler);
        tcpThread.start();
        // tcp 소켓 통신 수신 쓰레드

    }

    @Override
    public void onBackPressed(){
        if(drawerLayout.isDrawerOpen(GravityCompat.START)){
            drawerLayout.closeDrawer(GravityCompat.START);
        }else{
            super.onBackPressed();
        }
    }
    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.nav_home:
                Intent intent = new Intent(ShowActivity.this, MainActivity.class);
                startActivity(intent);
                break;
            case R.id.nav_show:
                break;
            case R.id.nav_favorite:
                Intent intent1 = new Intent(ShowActivity.this, FavoriteActivity.class);
                startActivity(intent1);
                break;
        }
        return true;
    }
}