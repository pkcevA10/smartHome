package com.example.why;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.ImageButton;

public class cctvActivity extends AppCompatActivity {

    ImageButton btn_previous;
    WebView cctvWeb;
    WebSettings webSettings;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cctv);

        btn_previous = findViewById(R.id.btn_previous);

        cctvWeb = findViewById(R.id.cctvweb);
        webSettings = cctvWeb.getSettings();
        cctvWeb.getSettings().setJavaScriptEnabled(true);
        cctvWeb.getSettings().setLoadWithOverviewMode(true);
        cctvWeb.getSettings().setUseWideViewPort(true);

        String url ="http://192.168.0.2:8081/";
        cctvWeb.loadUrl(url);

        btn_previous.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(cctvActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });

    }
}