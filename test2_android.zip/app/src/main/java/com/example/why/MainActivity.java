package com.example.why;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.github.angads25.toggle.widget.LabeledSwitch;
import com.google.android.material.navigation.NavigationView;

import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

public class MainActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    // Toolbar
    Toolbar toolbar;

    //Drawer Menu
    DrawerLayout drawerLayout;
    NavigationView navigationView;
    LinearLayout contentView;

    //ImageButton
    ImageButton btn_cctv;

    //Toggle Button
    LabeledSwitch Window;
    LabeledSwitch Light;
    LabeledSwitch Airconditioner;
    LabeledSwitch Fan;
    LabeledSwitch AutoMode;

    //Socket
    String ip = "192.168.0.2";     //192.168.56.1
    String str;
    Handler handler;
    String response;

    static final float END_SCALE = 0.7f;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        toolbar = findViewById(R.id.toolbar);
        drawerLayout = findViewById(R.id.drawer_layout);
        navigationView = findViewById(R.id.nav_view);

        contentView = findViewById(R.id.contentView);

        btn_cctv = findViewById(R.id.tvbtn_cctv);

        /* Toolbar */
        setSupportActionBar(toolbar);

        /* Navigation Drawer Menu */
        navigationView.bringToFront();
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawerLayout, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();

        navigationView.setNavigationItemSelectedListener(this);
        navigationView.setCheckedItem(R.id.nav_home);

        animateNavigationDrawer();

        //Toggle Button
        AutoMode = findViewById(R.id.tg_auto);
        Window = findViewById(R.id.tg_window);
        Light = findViewById(R.id.tg_light);
        Airconditioner = findViewById(R.id.tg_airconditioner);
        Fan = findViewById(R.id.tg_fan);

        handler = new Handler();

        //카메라 이벤트 리스너
        btn_cctv.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, cctvActivity.class);
            startActivity(intent);
        });

        //토글 버튼 이벤트 리스너
        Window.setOnToggledListener((toggleableView, isOn) -> {
            if(isOn){
                str = "M:0";
                SocketThread thread =new SocketThread(ip,str);
                thread.start();
            }else {
                str = "M:1";
                SocketThread thread = new SocketThread(ip, str);
                thread.start();
            }
        });

        Light.setOnToggledListener((toggleableView, isOn) -> {
            if(isOn){
                str = "RELAY_2:0";
                SocketThread thread =new SocketThread(ip,str);
                thread.start();
            }else {
                str = "RELAY_2:1";
                SocketThread thread =new SocketThread(ip,str);
                thread.start();
            }

        });

        Airconditioner.setOnToggledListener((toggleableView, isOn) -> {

            if(isOn){
                str = "AIR:0";
                SocketThread thread =new SocketThread(ip,str);
                thread.start();
            }else {
                str = "AIR:1";
                SocketThread thread =new SocketThread(ip,str);
                thread.start();
            }

        });

        Fan.setOnToggledListener((toggleableView, isOn) -> {

            if(isOn){
                str = "FAN:0";
                SocketThread thread =new SocketThread(ip,str);
                thread.start();
            }else {
                str = "FAN:1";
                SocketThread thread =new SocketThread(ip,str);
                thread.start();
            }

        });

        AutoMode.setOnToggledListener((toggleableView, isOn) -> {

            if(isOn){
                str = "AUTO:1";
                SocketThread thread =new SocketThread(ip,str);
                thread.start();
            }else{
                str = "AUTO:0";
                SocketThread thread =new SocketThread(ip,str);
                thread.start();
            }

        });
    }

    private void animateNavigationDrawer() {
        drawerLayout.setScrimColor(getResources().getColor(R.color.skyblue));
        drawerLayout.addDrawerListener(new DrawerLayout.SimpleDrawerListener() {
            @Override
            public void onDrawerSlide(View drawerView, float slideOffset) {
                //Scale the View based on current slide offset
                final float diffScaledOffset = slideOffset * (1 - END_SCALE);
                final float offsetScale = 1 - diffScaledOffset;
                contentView.setScaleX(offsetScale);
                contentView.setScaleY(offsetScale);

                //Translate the View, accounting for the saceld width
                final float xOffset = drawerView.getWidth() * slideOffset;
                final float xOffsetDiff = contentView.getWidth() * diffScaledOffset / 2;
                final float xTranslation = xOffset - xOffsetDiff;
                contentView.setTranslationX(xTranslation);
            }
        });

    }

    @Override
    public void onBackPressed() {
        if(drawerLayout.isDrawerOpen(GravityCompat.START)){
            drawerLayout.closeDrawer(GravityCompat.START);
        }else{
            super.onBackPressed();
        }
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {

        switch (menuItem.getItemId()){
            case R.id.nav_home:
                break;
            case R.id.nav_show:
                Intent intent = new Intent(MainActivity.this, ShowActivity.class);
                startActivity(intent);
                break;
            case R.id.nav_favorite:
                Intent intent1 = new Intent(MainActivity.this, FavoriteActivity.class);
                startActivity(intent1);
                break;
        }
        return true;
    }

    class SocketThread extends Thread{

        String host;
        String data;

        public SocketThread(String host, String data){
            this.host = host;
            this.data = data;
        }

        @Override
        public void run() {

            try{
                int port = 9999;    //3342
                Socket socket =new Socket(host, port);//소켓 열기
                ObjectOutputStream outStream = new ObjectOutputStream(socket.getOutputStream());//소켓의 출력 스트림 참조
                outStream.writeObject(data);//출력 스트림에 데이터 넣기
                outStream.flush();//출력

                ObjectInputStream inStream = new ObjectInputStream(socket.getInputStream()); //소켓의 입력 스트림 참조
                response = (String)inStream.readObject(); //응답 가져오기

                /* 토스트로 서버측 응답 결과 띄어줄 러너블 객체 생성해 메인 스레드 핸들러로 전달 */
                handler.post(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText(MainActivity.this,"서버 응답 : "+response, Toast.LENGTH_LONG).show();
                    }
                });

                socket.close();//소켓 해제

            }catch (Exception e){
                e.printStackTrace();
            }
            super.run();
        }
    }
}





